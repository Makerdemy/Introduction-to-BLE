| Supported Targets | ESP32 |
| ----------------- | ----- |

ESP BLE Mesh Sensor Server Example
==================================

For description of this example please refer to [ESP BLE Mesh Sensor Client Example](../sensor_client/README.md)
