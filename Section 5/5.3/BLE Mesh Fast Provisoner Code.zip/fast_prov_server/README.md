| Supported Targets | ESP32 |
| ----------------- | ----- |

ESP BLE Mesh Fast Provisioning Server example
========================

This example shows how a BLE Mesh device functions as a Fast Provisioning Server.

Please check the [tutorial](tutorial/BLE_Mesh_Fast_Prov_Server_Example_Walkthrough.md) for more information about this example.